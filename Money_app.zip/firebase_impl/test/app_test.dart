import 'package:flutter_test/flutter_test.dart';
import 'package:test/test.dart';

void main() {

    // group('Chat Application', () {
    //     //AuthForm Screen
    //     final usernameField = find.byValueKey('User Name');
    //     final passwordField = find.byValueKey('Password');
    //     final signInButton = find.byValueKey('Signup');
    //     final loginButton = find.byValueKey('Login');
    //     final anonLogButton = find.byValueKey('Anonymus Login');
    //
    //     });

}