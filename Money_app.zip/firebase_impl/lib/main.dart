import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_impl/screens/auth_scr.dart';
import 'package:firebase_impl/screens/chat_scr.dart';
import 'package:firebase_impl/screens/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await MobileAds.instance.initialize();
  runApp(MyApp());

}

class MyApp extends StatelessWidget {

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch:Colors.purple,
        backgroundColor: Colors.purple,
        accentColor: Colors.deepPurpleAccent,
        accentColorBrightness: Brightness.dark,
        buttonTheme: ButtonTheme.of(context).copyWith(
          buttonColor: Colors.teal,
          textTheme: ButtonTextTheme.primary,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
      ),
      // home: AuthScreen(),
      home: StreamBuilder(
        stream: FirebaseAuth.instance.onAuthStateChanged,builder: (ctx,userSnapshot){
          if(userSnapshot.hasData){
            return HomeScreen();
          }
          return AuthScreen();
      },
      ),
    );
  }
}