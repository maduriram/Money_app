import 'dart:io';

class AdHelper {
  static String get bannerAdUnitId {
    if (Platform.isAndroid) {
      return "ca-app-pub-6308227401506390/1828854045";
    } else if (Platform.isIOS) {
      return "ca-app-pub-6308227401506390/5029732458";
    } else {
      throw new UnsupportedError("Unsupported platform");
    }
  }

}